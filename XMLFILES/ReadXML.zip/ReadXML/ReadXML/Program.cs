﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace ReadXML
{
    class Program
    {
        static void Main(string[] args)
        {
            WebClient Client = new WebClient();
            Client.Credentials=new NetworkCredential("administrator","P@ssw0rd@321");

            byte[] filedata = Client.DownloadData("http://10.68.128.101/fmdsstest/XMLFILES/test.txt");

            FileStream file = File.Create("D:\\XMLFiles\\text.txt");
            file.Write(filedata,0,filedata.Length);
            file.Close();

            //Client.DownloadFile("10.68.128.101/fmdsstest/XMLFILES", "test.txt");
            
        }
    }
}
