$(document).ready(function(){
	var window_width = $(window).width();
	//------------menu slide script-----------------
	function menuSlide() {

	if(window_width => 768){
		$("#sidebar-toggle").bind("click", "focus", function(){
			$("body").toggleClass('sidebar-mini');
		});
		
		$(".treeview-menu").click(function(){
			$("body").removeClass('sidebar-mini');
		});
		
	}
	}
	
	function setheight(){
		var w_height = $(window).height();
		var w_width = $(window).width();
		if(w_width >= 767){
		$(".sidebar").css({"height": w_height});
			}
		else{
			$(".sidebar").css({"height": "auto"});
		}
	}
	
	menuSlide();
	setheight();
	
	$(window).resize(function () {
	menuSlide();
	setheight();
        });
	$(window).on("orientationchange", function () {
		menuSlide();
	setheight();
        });

});